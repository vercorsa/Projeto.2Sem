const Model = require('../models/UtilizadorModel');
const bcrypt = require('bcrypt');

async function getAllUtilizadores(req, res) {
  try {
    const data = await Model.getAll();
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

async function getUtilizadorById(req, res) {
  try {
    const row = await Model.getById(req.params.id);
    if (!row) return res.status(404).json({ message: 'Não encontrado' });
    res.json(row);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

async function createUtilizador(req, res) {
  try {
    const { PalavraPasse, ...rest } = req.body;
    const hash = await bcrypt.hash(PalavraPasse, 10);
    const id = await Model.create({ ...rest, PalavraPasse: hash });
    res.status(201).json({ ID_Utilizador: id });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}

async function updateUtilizador(req, res) {
  try {
    const { PalavraPasse, ...rest } = req.body;
    let updateData = rest;

    if (PalavraPasse) {
      const hash = await bcrypt.hash(PalavraPasse, 10);
      updateData.PalavraPasse = hash;
    }

    const affected = await Model.update(req.params.id, updateData);
    if (affected === 0) return res.status(404).json({ message: 'Não encontrado' });
    res.json({ message: 'Atualizado com sucesso' });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
}

async function deleteUtilizador(req, res) {
  try {
    const affected = await Model.remove(req.params.id);
    if (affected === 0) return res.status(404).json({ message: 'Não encontrado' });
    res.json({ message: 'Eliminado com sucesso' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

async function login(req, res) {
  try {
    const { Email, PalavraPasse } = req.body;
    const user = await Model.getByEmail(Email);

    if (!user) return res.status(401).json({ message: 'Credenciais inválidas' });

    const isMatch = await bcrypt.compare(PalavraPasse, user.PalavraPasse);
    if (!isMatch) return res.status(401).json({ message: 'Credenciais inválidas' });

    res.json({ message: 'Login bem-sucedido', utilizador: user });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

module.exports = {
  getAllUtilizadores,
  getUtilizadorById,
  createUtilizador,
  updateUtilizador,
  deleteUtilizador,
  login
};
