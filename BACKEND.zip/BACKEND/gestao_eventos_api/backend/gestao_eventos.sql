
-- Criação da base de dados
CREATE DATABASE IF NOT EXISTS gestao_eventos;
USE gestao_eventos;

-- ====================
-- TABELA: UTILIZADOR
-- ====================
CREATE TABLE Utilizador (
    ID_Utilizador INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Telefone VARCHAR(20),
    TipoUtilizador BOOLEAN NOT NULL, -- 0 = Participante, 1 = Administrador
    PalavraPasse VARCHAR(255) NOT NULL,
    ImagemPerfil TEXT -- URL ou base64 opcional
);

-- ====================
-- TABELA: CATEGORIA
-- ====================
CREATE TABLE Categoria (
    ID_Categoria INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL
);

-- ====================
-- TABELA: EVENTO
-- ====================
CREATE TABLE Evento (
    ID_Evento INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Data DATETIME NOT NULL,
    DataFim DATETIME,
    Local VARCHAR(100),
    TipoEvento BOOLEAN NOT NULL, -- 0 = Gratuito, 1 = Pago
    Descricao TEXT,
    LimiteParticipantes INT,
    AvaliacaoMedia FLOAT DEFAULT 0
);

-- ====================
-- TABELA: SALA
-- ====================
CREATE TABLE Sala (
    ID_Sala INT AUTO_INCREMENT PRIMARY KEY,
    NomeSala VARCHAR(100),
    Capacidade INT,
    Localizacao VARCHAR(100)
);

-- ====================
-- TABELA: RECURSO
-- ====================
CREATE TABLE Recurso (
    ID_Recurso INT AUTO_INCREMENT PRIMARY KEY,
    NomeRecurso VARCHAR(100),
    Tipo VARCHAR(50),
    QuantidadeDisponivel INT
);

-- ====================
-- TABELA: ORADOR
-- ====================
CREATE TABLE Orador (
    ID_Orador INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Bio TEXT,
    Email VARCHAR(100)
);

-- =========================
-- TABELAS RELACIONAIS
-- =========================

CREATE TABLE Evento_Sala (
    ID_Evento INT,
    ID_Sala INT,
    PRIMARY KEY (ID_Evento, ID_Sala),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento),
    FOREIGN KEY (ID_Sala) REFERENCES Sala(ID_Sala)
);

CREATE TABLE Evento_Recurso (
    ID_Evento INT,
    ID_Recurso INT,
    QuantidadeUsada INT,
    PRIMARY KEY (ID_Evento, ID_Recurso),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento),
    FOREIGN KEY (ID_Recurso) REFERENCES Recurso(ID_Recurso)
);

CREATE TABLE Evento_Orador (
    ID_Evento INT,
    ID_Orador INT,
    TituloPalestra VARCHAR(200),
    Horario DATETIME,
    PRIMARY KEY (ID_Evento, ID_Orador),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento),
    FOREIGN KEY (ID_Orador) REFERENCES Orador(ID_Orador)
);

CREATE TABLE Evento_Categoria (
    ID_Evento INT,
    ID_Categoria INT,
    PRIMARY KEY (ID_Evento, ID_Categoria),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento),
    FOREIGN KEY (ID_Categoria) REFERENCES Categoria(ID_Categoria)
);

CREATE TABLE Preferencia_Categoria (
    ID_Utilizador INT,
    ID_Categoria INT,
    PRIMARY KEY (ID_Utilizador, ID_Categoria),
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID_Utilizador),
    FOREIGN KEY (ID_Categoria) REFERENCES Categoria(ID_Categoria)
);

-- ============================
-- TABELAS DE PARTICIPAÇÃO
-- ============================

CREATE TABLE Inscricao (
    ID_Inscricao INT AUTO_INCREMENT PRIMARY KEY,
    ID_Utilizador INT,
    ID_Evento INT,
    DataInscricao DATETIME DEFAULT CURRENT_TIMESTAMP,
    Status VARCHAR(20) DEFAULT 'Confirmada',
    UNIQUE (ID_Utilizador, ID_Evento),
    CHECK (Status IN ('Confirmada', 'Cancelada', 'Lista de Espera')),
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID_Utilizador),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento)
);

CREATE TABLE Bilhete (
    ID_Bilhete INT AUTO_INCREMENT PRIMARY KEY,
    QRCode LONGBLOB NOT NULL,
    DataEmissao DATETIME DEFAULT CURRENT_TIMESTAMP,
    Validado BOOLEAN DEFAULT 0,
    ID_Inscricao INT UNIQUE,
    FOREIGN KEY (ID_Inscricao) REFERENCES Inscricao(ID_Inscricao)
);

-- ============================
-- FEEDBACK & INTERAÇÃO
-- ============================

CREATE TABLE Avaliacao (
    ID_Avaliacao INT AUTO_INCREMENT PRIMARY KEY,
    ID_Utilizador INT,
    ID_Evento INT,
    Pontuacao INT,
    DataAvaliacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (ID_Utilizador, ID_Evento),
    CHECK (Pontuacao BETWEEN 1 AND 5),
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID_Utilizador),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento)
);

CREATE TABLE Comentario (
    ID_Comentario INT AUTO_INCREMENT PRIMARY KEY,
    ID_Utilizador INT,
    ID_Evento INT,
    Texto TEXT,
    DataComentario DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID_Utilizador),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento)
);

CREATE TABLE Feedback (
    ID_Feedback INT AUTO_INCREMENT PRIMARY KEY,
    ID_Utilizador INT,
    ID_Evento INT,
    ID_Comentario INT,
    Respostas TEXT,
    DataResposta DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID_Utilizador),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento),
    FOREIGN KEY (ID_Comentario) REFERENCES Comentario(ID_Comentario)
);

-- ============================
-- NOTIFICAÇÕES
-- ============================
CREATE TABLE Notificacao (
    ID_Notificacao INT AUTO_INCREMENT PRIMARY KEY,
    ID_Utilizador INT,
    Tipo VARCHAR(10),
    Mensagem TEXT,
    DataEnvio DATETIME DEFAULT CURRENT_TIMESTAMP,
    ID_Evento INT,
    CHECK (Tipo IN ('Email', 'SMS')),
    FOREIGN KEY (ID_Utilizador) REFERENCES Utilizador(ID_Utilizador),
    FOREIGN KEY (ID_Evento) REFERENCES Evento(ID_Evento)
);
