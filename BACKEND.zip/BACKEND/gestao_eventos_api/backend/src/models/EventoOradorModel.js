
const pool = require('./conectar');
const TABLE = 'EventoOrador';
const PK    = 'ID_EventoOrador';
const FIELDS= ['ID_Evento','ID_Orador'];

async function getAll(){ const [rows] = await pool.query(`SELECT * FROM ${TABLE}`); return rows; }
async function getById(id){ const [rows] = await pool.query(`SELECT * FROM ${TABLE} WHERE ${PK} = ?`, [id]); return rows[0]; }
async function create(obj){
  const [result] = await pool.query(
    `INSERT INTO ${TABLE} (ID_Evento,ID_Orador) VALUES (?,?)`,
    [obj.ID_Evento,obj.ID_Orador]
  );
  return result.insertId;
}
async function update(id,obj){
  const [result] = await pool.query(
    `UPDATE ${TABLE} SET ID_Evento=?,ID_Orador=? WHERE ${PK} = ?`,
    [obj.ID_Evento,obj.ID_Orador,id]
  );
  return result.affectedRows;
}
async function remove(id){
  const [result] = await pool.query(`DELETE FROM ${TABLE} WHERE ${PK} = ?`, [id]);
  return result.affectedRows;
}

module.exports = { getAll, getById, create, update, remove };
