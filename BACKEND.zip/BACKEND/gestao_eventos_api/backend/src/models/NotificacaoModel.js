const pool = require('./conectar');
const TABLE = 'Notificacao';
const PK    = 'ID_Notificacao';
const FIELDS= ['ID_Utilizador','Mensagem','DataEnvio','Lida'];

async function getAll(){ const [rows] = await pool.query(`SELECT * FROM ${TABLE}`); return rows; }
async function getById(id){ const [rows] = await pool.query(`SELECT * FROM ${TABLE} WHERE ${PK} = ?`, [id]); return rows[0]; }
async function create(obj){
  const vals   = [obj.ID_Utilizador,obj.Mensagem,obj.DataEnvio,obj.Lida];
  const [result] = await pool.query(
    `INSERT INTO ${TABLE} (ID_Utilizador,Mensagem,DataEnvio,Lida) VALUES (?,?,?,?)`,
    vals
  );
  return result.insertId;
}
async function update(id,obj){
  const vals   = [obj.ID_Utilizador,obj.Mensagem,obj.DataEnvio,obj.Lida];
  const [result] = await pool.query(
    `UPDATE ${TABLE} SET ID_Utilizador=?,Mensagem=?,DataEnvio=?,Lida=? WHERE ${PK} = ?`,
    [...vals,id]
  );
  return result.affectedRows;
}
async function remove(id){
  const [result] = await pool.query(`DELETE FROM ${TABLE} WHERE ${PK} = ?`, [id]);
  return result.affectedRows;
}

module.exports = { getAll, getById, create, update, remove };
