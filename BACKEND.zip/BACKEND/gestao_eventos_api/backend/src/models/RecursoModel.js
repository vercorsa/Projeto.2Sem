const pool = require('./conectar');
const TABLE = 'Recurso';
const PK    = 'ID_Recurso';
const FIELDS= ['Nome','Tipo','Descricao'];

async function getAll(){ const [rows] = await pool.query(`SELECT * FROM ${TABLE}`); return rows; }
async function getById(id){ const [rows] = await pool.query(`SELECT * FROM ${TABLE} WHERE ${PK} = ?`, [id]); return rows[0]; }
async function create(obj){
  const values = FIELDS.map(f => obj[f]);
  const [result] = await pool.query(
    `INSERT INTO ${TABLE} (${FIELDS.join()}) VALUES (${FIELDS.map(_=>'?' ).join()})`,
    values
  );
  return result.insertId;
}
async function update(id,obj){
  const values = FIELDS.map(f => obj[f]);
  const [result] = await pool.query(
    `UPDATE ${TABLE} SET ${FIELDS.map(f=>`${f} = ?`).join(', ')} WHERE ${PK} = ?`,
    [...values,id]
  );
  return result.affectedRows;
}
async function remove(id){
  const [result] = await pool.query(`DELETE FROM ${TABLE} WHERE ${PK} = ?`, [id]);
  return result.affectedRows;
}

module.exports = { getAll, getById, create, update, remove };
