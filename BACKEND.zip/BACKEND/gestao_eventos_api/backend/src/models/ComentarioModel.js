const pool = require('./conectar');
const TABLE = 'Comentario';
const PK    = 'ID_Comentario';
const FIELDS= ['ID_Evento','ID_Utilizador','Texto','DataComentario']

async function getAll(){ const [rows] = await pool.query(`SELECT * FROM ${TABLE}`); return rows; }
async function getById(id){ const [rows] = await pool.query(`SELECT * FROM ${TABLE} WHERE ${PK} = ?`, [id]); return rows[0]; }
async function create(obj){
  const vals   = [obj.ID_Evento,obj.ID_Utilizador,obj.Texto,obj.DataComentario];
  const [result] = await pool.query(
    `INSERT INTO ${TABLE} (ID_Evento,ID_Utilizador,Texto,DataComentario) VALUES (?,?,?,?)`,
    vals
  );
  return result.insertId;
}
async function update(id,obj){
  const vals   = [obj.ID_Evento,obj.ID_Utilizador,obj.Texto,obj.DataComentario];
  const [result] = await pool.query(
    `UPDATE ${TABLE} SET ID_Evento=?,ID_Utilizador=?,Texto=?,DataComentario=? WHERE ${PK} = ?`,
    [...vals,id]
  );
  return result.affectedRows;
}
async function remove(id){
  const [result] = await pool.query(`DELETE FROM ${TABLE} WHERE ${PK} = ?`, [id]);
  return result.affectedRows;
}

module.exports = { getAll, getById, create, update, remove };
