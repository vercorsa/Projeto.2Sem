
const pool = require('./conectar');
const TABLE = 'Bilhete';
const PK    = 'ID_Bilhete';
const FIELDS= ['ID_Inscricao','Codigo','Preco'];

async function getAll(){ const [rows] = await pool.query(`SELECT * FROM ${TABLE}`); return rows; }
async function getById(id){ const [rows] = await pool.query(`SELECT * FROM ${TABLE} WHERE ${PK} = ?`, [id]); return rows[0]; }
async function create(obj){
  const [result] = await pool.query(
    `INSERT INTO ${TABLE} (ID_Inscricao,Codigo,Preco) VALUES (?,?,?)`,
    [obj.ID_Inscricao,obj.Codigo,obj.Preco]
  );
  return result.insertId;
}
async function update(id,obj){
  const [result] = await pool.query(
    `UPDATE ${TABLE} SET ID_Inscricao=?,Codigo=?,Preco=? WHERE ${PK} = ?`,
    [obj.ID_Inscricao,obj.Codigo,obj.Preco,id]
  );
  return result.affectedRows;
}
async function remove(id){
  const [result] = await pool.query(`DELETE FROM ${TABLE} WHERE ${PK} = ?`, [id]);
  return result.affectedRows;
}

module.exports = { getAll, getById, create, update, remove };
