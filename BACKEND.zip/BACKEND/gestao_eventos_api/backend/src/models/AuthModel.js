// src/models/AuthModel.js
const db = require('../db'); // Ajusta para o teu módulo de conexão ao BD


//Regista um novo utilizador na tabela Utilizador.
//@param {{ nome: string, email: string, password: string }} data
//@returns {Promise<number>} ID do utilizador criado/
async function register(data) {
  const { nome, email, password } = data;
  const [result] = await db.query(
    'INSERT INTO Utilizador (nome, email, password) VALUES (?, ?, ?)',
    [nome, email, password]
  );
  return result.insertId;
}


//Procura um utilizador pelo email.
//@param {string} email
//@returns {Promise<Object|null>} O utilizador (incluindo a hash da password) ou null se não existir/
async function findByEmail(email) {
  const [rows] = await db.query(
    'SELECT * FROM Utilizador WHERE email = ?',
    [email]
  );
  return rows.length > 0 ? rows[0] : null;
}

module.exports = {
  register,
  findByEmail
};