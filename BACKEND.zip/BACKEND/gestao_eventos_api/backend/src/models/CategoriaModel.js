const pool = require('./conectar');
const TABLE = 'Categoria';
const PK = 'ID_Categoria';
const FIELDS = ['Nome'];

async function getAll()    { const [rows] = await pool.query(`SELECT * FROM ${TABLE}`); return rows; }
async function getById(id)  { const [rows] = await pool.query(`SELECT * FROM ${TABLE} WHERE ${PK} = ?`, [id]); return rows[0]; }
async function create(obj)  {
  const [result] = await pool.query(
    `INSERT INTO ${TABLE} (${FIELDS.join()}) VALUES (?)`,
    [obj.Nome]
  );
  return result.insertId;
}
async function update(id,obj){
  const [result] = await pool.query(
    `UPDATE ${TABLE} SET Nome = ? WHERE ${PK} = ?`,
    [obj.Nome,id]
  );
  return result.affectedRows;
}
async function remove(id){
  const [result] = await pool.query(`DELETE FROM ${TABLE} WHERE ${PK} = ?`, [id]);
  return result.affectedRows;
}

module.exports = { getAll, getById, create, update, remove };
