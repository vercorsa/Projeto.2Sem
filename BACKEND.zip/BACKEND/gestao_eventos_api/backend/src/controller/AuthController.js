// src/controllers/AuthController.js
const UserModel = require('../models/UtilizadorModel');
const bcrypt    = require('bcrypt');
const jwt       = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET || 'troque_pra_algo_seguro';

async function register(req, res) {
  try {
    const { email, password, nome } = req.body;
    // 1) Verifica se já existe
    const existing = await UserModel.getByEmail(email);
    if (existing) {
      return res.status(400).send({ error: 'Já existe um utilizador com esse email' });
    }
    // 2) Hash da password
    const hash = await bcrypt.hash(password, 10);
    // 3) Cria no banco
    const id = await UserModel.create({ email, password: hash, nome });
    // 4) Retorna
    res.status(201).send({ message: 'Registo efetuado com sucesso', ID_Utilizador: id });
  } catch (e) {
    res.status(500).send({ error: e.message });
  }
}

async function login(req, res) {
  try {
    const { email, password } = req.body;
    const user = await UserModel.getByEmail(email);
    if (!user) {
      return res.status(401).send({ error: 'Credenciais inválidas' });
    }
    // 1) Compara hash
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).send({ error: 'Credenciais inválidas' });
    }
    // 2) Gera token JWT
    const payload = { id: user.ID_Utilizador, email: user.email };
    const token   = jwt.sign(payload, JWT_SECRET, { expiresIn: '2h' });
    // 3) Retorna token
    res.send({ message: 'Login efetuado com sucesso', token });
  } catch (e) {
    res.status(500).send({ error: e.message });
  }
}

module.exports = {
  register,
  login
};