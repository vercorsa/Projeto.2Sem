package com.example.pbl_v3;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
