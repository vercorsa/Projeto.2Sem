import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const _baseUrl = 'http://10.0.2.2:3000/api';

  Future<Map<String, dynamic>> login(String email, String password) async {
    final resp = await http.post(
      Uri.parse('$_baseUrl/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    return _processResponse(resp);
  }

  Future<Map<String, dynamic>> register(String name, String email, String password) async {
    final resp = await http.post(
      Uri.parse('$_baseUrl/auth/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );
    return _processResponse(resp);
  }

  Map<String, dynamic> _processResponse(http.Response resp) {
    final body = jsonDecode(resp.body);
    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return {'success': true, 'data': body};
    } else {
      return {'success': false, 'message': body['error'] ?? 'Erro desconhecido'};
    }
  }
}
