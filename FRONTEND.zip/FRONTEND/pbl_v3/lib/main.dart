import 'package:flutter/material.dart';
import 'splashScreen/splash_screen.dart';
import 'splashScreen/tutorial1.dart';
import 'splashScreen/tutorial2.dart';
import 'splashScreen/tutorial3.dart';

void main() => runApp(const CampusEventsApp());

class CampusEventsApp extends StatelessWidget {
  const CampusEventsApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Campus Events',
      theme: ThemeData(primarySwatch: Colors.blue),
      initialRoute: SplashScreen.routeName,
      routes: {
        SplashScreen.routeName: (_) => const SplashScreen(),
        Tutorial1.routeName: (_) => const Tutorial1(),
        Tutorial2.routeName: (_) => const Tutorial2(),
        Tutorial3.routeName: (_) => const Tutorial3(),
      },
    );
  }
}
