import 'package:flutter/material.dart';
import '../widgets/tutorial_screen.dart';

class Tutorial3 extends StatelessWidget {
  static const routeName = '/tutorial3';
  const Tutorial3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TutorialScreen(
      imagePath: 'assets/horarios.png',
      title: 'Horários',
      subtitle: 'Consulte os horários dos eventos em tempo real',
      currentStep: 2,
      onTap: () {
        // TODO: navegar para a próxima tela (por exemplo, Home)
      },
    );
  }
}
