-- Criar login global no SQL Server
CREATE LOGIN pbl_user WITH PASSWORD = 'PblUser2025!';

-- Usar o banco do projeto
USE gestao_eventos;

-- Criar usuário vinculado ao login
CREATE USER pbl_user FOR LOGIN pbl_user;

-- Dar permissões completas
EXEC sp_addrolemember 'db_owner', 'pbl_user';
